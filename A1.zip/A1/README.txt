CPRG 251 A1 (Mod 1-3) Winter 2022

ABC Book Company

This program can read the book.txt file into an Arraylist,
checkout a book by using book ISBN and change the available book form the Database afterward.
The program can display books by their type/category and then as well as
printing a list of random books

Input fields:
Option
Book ISBN
Type 
Format, Diet, Genre or Frequency (depending on type)
Amount of Random books

Implementations:
Load the books
Check out books
Save Changes to File
Search for books
Display Books by type
Generate Random Books

Date: Feb 11, 2022
Author: Phi Nguyen

To run this program, the user must have installed Java files and its JDK as well as a Java IDE (e.g Netbeans, Eclipse, etc) since it is easier to navigate.
The JAR file enables the user to run it via Command Line (cmd) on Windows without installing a Java IDE
To Run the JAR file, first, the user needs to use cmd command 
java -jar filename.jar
where filename is the name of the application that you want to run
With Eclipse IDE, the user can run the application by openning the project and click "Run" on the navigation bar