CPRG 251 A2 Winter 2022

Flight management system

This program can read the flights.csv and airports.csv files into Arraylists,
The program allows user to interact via a user interface, allowing them to find flights, make reservations, update personal information

Input fields:
Name,
citizenship,
flight information

Implementations:
Find flight,
Find reservation,
Make reservation,
Update information

Date: Mar 28, 2022
Author: Phi Nguyen

To run this program, the user must have installed Java files and its JDK as well as a Java IDE (e.g Netbeans, Eclipse, etc) since it is easier to navigate.
The JAR file enables the user to run it via Command Line (cmd) on Windows without installing a Java IDE
To Run the JAR file, first, the user needs to use cmd command 
java -jar filename.jar
where filename is the name of the application that you want to run
With Eclipse IDE, the user can run the application by openning the project and click "Run" on the navigation bar