module Nguyen {
	exports sait.frms.application;
	exports sait.frms.gui;
	exports sait.frms.exception;
	exports sait.frms.manager;
	exports sait.frms.problemdomain;

	requires java.desktop;
}