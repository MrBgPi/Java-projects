package sait.frms.application;

import sait.frms.gui.MainWindow;

import java.io.IOException;


/**
 * Application driver.
 * @author Phi Nguyen
 */
public class AppDriver {

	/**
	 * Entry point to Java application.
	 * @param args
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) throws NumberFormatException, IOException {
		MainWindow mainWindow = new MainWindow();
		mainWindow.display();
	}

}
