package sait.frms.exception;

/**
 * The class InvalidCitizenship throws 
 * an exception when citizenship can't be found. 
 * @author Phi Nguyen 
 */
	 
public class InvalidCitizenshipException extends Exception {
	public InvalidCitizenshipException() {
		super("Citizenship not found. Please check your submit form.");
	}
}
