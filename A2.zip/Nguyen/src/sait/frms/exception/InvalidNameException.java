package sait.frms.exception;

/**
 * The class InvalidNameException throws an exception 
 * when name is missing
 * @author Phi Nguyen
 */

public class InvalidNameException extends Exception {
	public InvalidNameException() {
		super("Name not found. Please check your submit form.");
	}
}