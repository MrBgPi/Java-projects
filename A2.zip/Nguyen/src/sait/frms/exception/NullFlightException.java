package sait.frms.exception;

/**
 * The class NullFlightException throws an exception 
 * when flight is not found
 * @author Phi Nguyen
 */

public class NullFlightException extends Exception {
	public NullFlightException() {
		super("Flight not found!");
	}
}
