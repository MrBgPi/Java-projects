package sait.frms.exception;

/**
 * The class UnavailableSeatException throws an exception 
 * when there is no more seats.
 * @author Phi Nguyen
 */

public class UnavailableSeatException extends Exception {
	public UnavailableSeatException() {
		super("No more seats available! Please choose another flight.");
	}
}