package sait.frms.gui;

import javax.swing.*;

/**
 * Abstract class for a tab in the JFrame.
 * @author Phi Nguyen
 */
public abstract class TabBase 
{
	/**
	 * Tab panel attribute.
	 */
	protected JPanel panel;
	
	/**
	 * Default constructor.
	 */
	protected TabBase() {
		this.panel = new JPanel();
	}
	
	/**
	 * Gets the panel containing the tab components.
	 * @return JPanel with components.
	 */
	public JPanel getPanel() {
		return this.panel;
	}
	
	/**
	   * Clear value of fields in tabs
	   * Used for tabs
	   * and main window when switching tabs
	   */
	   protected abstract void emptyFields();

	   /**
	   * Clear value in list in tabs
	   * Used for tabs
	   * and main window when switching tabs
	   */
	   protected abstract void clearList();

	   /**
	   * Clear value of filters in tabs
	   * Used for tabs
	   * and main window when switching tabs
	   */
	   protected abstract void clearFilters();
}
