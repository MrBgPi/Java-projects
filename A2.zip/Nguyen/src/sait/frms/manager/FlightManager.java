package sait.frms.manager;

import java.util.*;
import java.io.*;

import sait.frms.problemdomain.Flight;
/**
 * The class finds flight by asking for the from and to,
 * and a day of the week of the flight
 * @author Phi Nguyen
 */
public class FlightManager {
	public final String WEEKDAY_ANY = "Any";
	public final String WEEKDAY_SUNDAY = "Sunday";
	public final String WEEKDAY_MONDAY = "Monday";
	public final String WEEKDAY_TUESDAY = "Tuesday";
	public final String WEEKDAY_WEDNESDAY = "Wednesday";
	public final String WEEKDAY_THURSDAY = "Thursday";
	public final String WEEKDAY_FRIDAY = "Friday";
	public final String WEEKDAY_SATURDAY = "Saturday";
	private ArrayList<Flight> flights;
	private ArrayList<String> airports;
	
	/**
	 * Constructor
	 * @param flights 
	 * @param airports
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public FlightManager() throws NumberFormatException, IOException {
		this.airports = new ArrayList<String> ();
		this.populateAirports();
		
		this.flights = new ArrayList<Flight> ();
		this.populateFlights();
	}

	/**
	 * @return the flights
	 */
	public ArrayList<Flight> getFlights() {
		return flights;
	}

	/**
	 * @return the airports
	 */
	public ArrayList<String> getAirports() {
		return airports;
	}
	/**
         * to find airport by typing in code
         * @param code
         * @return airportName
         * @throws FileNotFoundException
         * @throws IOException 
         */
	public String findAirportByCode(String code) throws IOException {
            String line;
            String[] cols;
            String airportName="";
            BufferedReader bReader = new BufferedReader(new FileReader("res/airports.csv"));
            while ((line = bReader.readLine()) != null) {          
                cols = line.split(",");
                if(cols[0] == code) {
                        airportName = cols[1];
                }
            }
            bReader.close();
            return airportName;
            
	}
        /**
         * to find flight by code
         * @param code
         * @return flight
         */
	public Flight findFlightByCode(String code) {
		for (Flight flight : this.flights) {
			if (flight.getCode().equals(code)) {
				return flight;
			}
		}
		return null;
	}
	/**
         * to find flight based on from, to and weekday
         * @param from
         * @param to
         * @param weekday
         * @return 
         */
	public ArrayList<Flight> findFlights(String from, String to, String weekday) {
		ArrayList<Flight> filteredFlights = new ArrayList<Flight>();
                this.flights.stream().filter((flight) -> (flight.getFrom().equals(from) && flight.getTo().equals(to))).forEachOrdered((flight) -> {
                    if (weekday.equals(WEEKDAY_ANY)) {
                        filteredFlights.add(flight);
                    }
                    else {
                        if (flight.getWeekday().equals(weekday) ) {
                            filteredFlights.add(flight);
                        }
                    }
            });

		return filteredFlights;
                
	}
	/**
         * to read and load data from flights.csv and assign them to flights object
         */
	private void populateFlights() throws IOException {
            String line;
            String[] cols;

            BufferedReader bReader = new BufferedReader(new FileReader("res/flights.csv"));
            while ((line = bReader.readLine()) != null) {          
            cols = line.split(",");
            if(cols[0].matches("OA(.*)") 
                            || cols[0].matches("CA(.*)")
                            || cols[0].matches("TB(.*)")
                            || cols[0].matches("VA(.*)")) {

                    this.flights.add(new Flight(
                                    cols[0], //code
                                    cols[1], //from
                                    cols[2], //to
                                    cols[3], // date
                                    cols[4], // time
                                    Integer.parseInt(cols[5]), // seat
                                    Double.parseDouble(cols[6]) //cost
                                    ));
                }
            }
            bReader.close();
            
	}
	/**
         * to read and load airports.csv file. Throwing FileNotFoundException if file does not exist
         */
	private void populateAirports()  {
            try {
                    Scanner file = new Scanner(new FileInputStream("res/airports.csv"), "UTF-8");
                    String line = "";
                    while (file.hasNextLine()) {
                            line = file.nextLine();
                            String cols[] = line.split(",");
                            this.airports.add(cols[0]);
                    }
                    file.close();
            }
            catch ( FileNotFoundException e ) {
                    System.out.println(e.getMessage());
            }
	}
}
