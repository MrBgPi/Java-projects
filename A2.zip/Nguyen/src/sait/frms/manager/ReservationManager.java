package sait.frms.manager;
import sait.frms.exception.*;

import java.io.*;
import java.util.*;
import sait.frms.problemdomain.Flight;
import sait.frms.problemdomain.Reservation;
/**
 * the class makes reservation and finds a asking for reservation's code, airline, and name 
 * @author Phi Nguyen
 */
public class ReservationManager {
	private ArrayList<Reservation> reservations;

	/**
	 * Constructor
	 * @param reservations
	 * @throws IOException 
	 */
	public ReservationManager() throws IOException {
		reservations = new ArrayList<Reservation>();
		populate();
	}
	/**
         * get reservations from arraylist
         * @return reservations
         */
	public ArrayList<Reservation> getReservations() {
		return this.reservations;
	}
	/**
         * to make reservation based on flight, name, and citizenship
         * if one of these are undefined, the method throws exceptions 
         * depending on the type of undefined value
         * @param flight
         * @param name
         * @param citizenship
         * @return
         * @throws NullFlightException
         * @throws InvalidNameException
         * @throws InvalidCitizenshipException
         * @throws UnavailableSeatException 
         */
	public Reservation makeReservation (Flight flight, String name, String citizenship) throws NullFlightException, InvalidNameException, InvalidCitizenshipException, UnavailableSeatException {
		
		if (flight == null) throw new NullFlightException();			
		else if (name.equals("")) throw new InvalidNameException();	
		else if (citizenship.equals("")) throw new InvalidCitizenshipException();		
		else if (getAvailableSeats(flight) == 0 ) throw new UnavailableSeatException();			
		else {
			Reservation res = new Reservation(
					generateReservationCode(flight), // get code
					flight.getCode(),
					flight.getAirlineName(),
					name,
					citizenship,
					flight.getCostPerSeat(),
					true                               
			);
			reservations.add(res);
			return res;
		}
	}
        /**
         * to find reservation based on flight code, airline and customer's name
         * @param code
         * @param airline
         * @param name
         * @return filteredReservations
         */
	public ArrayList<Reservation> findReservations (String code, String airline, String name) {
		ArrayList<Reservation> filteredReservations = new ArrayList<Reservation>();
                this.reservations.stream().filter((res) -> ((code.equals("") || res.getCode().equals(code))
                        && (airline.equals("") || res.getAirline().equals(airline))
                        && (name.equals("") || res.getName().equals(name))
                        && (!code.equals("") || !airline.equals("") || !name.equals(""))
                        )).forEachOrdered((res) -> {
                            filteredReservations.add(res);
                });
		return filteredReservations;
	}
        /**
         * to get reservation information by typing in code
         * @param code
         * @return res
         */
	public Reservation findReservationByCode (String code) {
		for (Reservation res : this.reservations) {
			if (res.getCode().equals(code)) {
				return res;
			}
		}
		return null;
	}
	/**
         * to write into random access file
         */
	public void persist() {		
		try {
                    try (RandomAccessFile raf = new RandomAccessFile ("res/reservations.dat", "rw")) {
                        for (Reservation r : reservations) {                                                     
                            raf.writeUTF(r.getCode());
                            raf.writeUTF(r.getFlightCode());
                            raf.writeUTF(r.getAirline());
                            raf.writeUTF(r.getName());
                            raf.writeUTF(r.getCitizenship());                          
                            raf.writeBoolean(r.isActive());
                            raf.writeDouble(r.getCost());

                        }
                    }
		}
		catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}
	/**
         * to get available seats
         * @param flight
         * @return flight.getSeats()
         */
	private int getAvailableSeats (Flight flight) {
		return flight.getSeats();
	}
	/**
         * to randomly generate reservation code
         * @param flight
         * @return generatedCode
         */
	private String generateReservationCode(Flight flight) {
		String generatedCode = ((flight.isDomestic()) ? "D" : "L") + (new Random().nextInt(9000) + 1000);
		boolean flag = true;
		while (flag) {
			flag = false;			
			for (Reservation res : reservations) {
				if (res.getCode().equals(generatedCode) && res.isActive()) {
					flag = true;
				}
			}
			if (flag) {
				generatedCode = (( flight.isDomestic()) ? "D" : "L") + (new Random().nextInt(9000) + 1000);
			}
		}
		return generatedCode;
	}
        /**
         * to read and load data from .dat file
         */
	private void populate() {
		try {
			RandomAccessFile raf = new RandomAccessFile ("res/reservations.dat", "rw");
			while (raf.getFilePointer() < raf.length() ) {
				this.reservations.add(new Reservation(					
					
                                         raf.readUTF(),
					raf.readUTF(),
					raf.readUTF(),
					raf.readUTF(),
					raf.readUTF(),
					raf.readDouble(),raf.readBoolean()
                                         
				));
			}
			raf.close();
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

}
