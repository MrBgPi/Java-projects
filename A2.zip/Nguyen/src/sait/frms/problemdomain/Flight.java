package sait.frms.problemdomain;
/**
 * instantiate Flight objects
 * @author Phi Nguyen
 */
public class Flight {
	private String code;
	private String airlineName;
	private String from;
	private String to;
	private String weekday;
	private String time;
	private int seats;
	private double costPerSeat;
	/**
         * Constructor
         * @param code
         * @param from
         * @param to
         * @param weekday
         * @param time
         * @param seats
         * @param costPerSeat 
         */
	public Flight(String code, String from, String to, String weekday, String time, int seats, double costPerSeat) {
		this.code = code;		
		this.from = from;
		this.to = to;		
		this.weekday = weekday;
		this.time = time;
		this.seats = seats;
		this.costPerSeat = costPerSeat;
		parseCode(code);
	}
	/**
         * to get code name   
         * @return  code
         */
	public String getCode() {
		return code;
	}
	/**
         * to get airline name
         * @return airlineName
         */
	public String getAirlineName() {
		return airlineName;
		
	}
        /**
         * get flight's origin
         * @return from
         */
	public String getFrom() {
		return from;
	}
        /**
         * get flight's destination
         * @return to
         */
	public String getTo() {
		return to;
	}
        /**
         * get date
         * @return weekday
         */
	public String getWeekday() {
		return weekday;
	}
        /**
         * get exact time
         * @return time
         */
	public String getTime() {
		return time;
	}
        /**
         * get available seats
         * @return seats
         */
	public int getSeats() {
		return seats;
	}
        /**
         * get cost for one seat
         * @return costPerSeat
         */
	public double getCostPerSeat() {
		return costPerSeat;
	}
        /**
         * check if flight is domestic
         * @return isDomestic
         */
	public boolean isDomestic() {		
		return (this.from.charAt(0) == 'Y' && this.to.charAt(0) == 'Y');
	}
        /**
         * parse code method to determine airline name
         * @param code 
         */
	private void parseCode(String code) {
		if ( null == code ) this.airlineName = "Vertical Airways";
		else switch (code) {
                    case "OA":
                        this.airlineName = "Otto Airlines";
                        break;
                    case "CA":
                        this.airlineName = "Conned Air";
                        break;
                    case "TB":
                        this.airlineName = "Try a Bus Airways";
                        break;
                    default:
                        this.airlineName = "Vertical Airways";
                        break;
            }
	}
        /**
         * toString method
         */
	public String toString() {
            return String.format("%s, From: %s, To: %s, Date: %s, Cost: %s", code, from, to, weekday, costPerSeat);
	}
}
