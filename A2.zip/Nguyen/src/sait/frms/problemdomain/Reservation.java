package sait.frms.problemdomain;

import sait.frms.exception.InvalidCitizenshipException;
import sait.frms.exception.InvalidNameException;
/**
 * instantiate Reservation objects
 * @author Phi Nguyen
 */
public class Reservation {
	private String code;
	private String flightCode; 
	private String airline;
	private String name;
	private String citizenship;
	private double cost;
	private boolean isActive;
	/**
         * Constructor
         * @param code
         * @param flightCode
         * @param airline
         * @param name
         * @param citizenship
         * @param cost
         * @param isActive 
         */
	public Reservation (String code, String flightCode, String airline, String name, String citizenship, double cost, boolean isActive) {
		this.code = code;
		this.flightCode = flightCode;
		this.airline = airline;
		this.name = name;
		this.citizenship = citizenship;
		this.cost = cost;
		this.isActive = isActive;
	}
	/**
         * A method to get code
         * @return code
         */
	public String getCode() {
		return code;
	}
        /**
         *  to get flight code
         * @return flightCode
         */
	public String getFlightCode() {
		return flightCode;
	}
        /**
         * to get Airline information
         * @return airline
         */
	public String getAirline() {
		return airline;
	} 
        /**
         * get customer's name
         * @return name
         */
	public String getName() {
		return name;
	}
        /**
         * get customer's citizenship
         * @return citizenship
         */
	public String getCitizenship() {
		return citizenship;
	}
        /**
         * get flight price
         * @return cost
         */
	public double getCost() {
		return cost;
		
	}
        /**
         * get active status or not
         * @return isActive
         */
	public boolean isActive() {
		return isActive;
	}
        /**
         * set customer's name
         * @param name
         * @throws InvalidNameException 
         */
	public void setName(String name) throws InvalidNameException {
		if (name == "") {
			throw new InvalidNameException();
		} else {
			this.name = name;
		}
	}
        /**
         * set customer's citizenship
         * @param citizenship
         * @throws InvalidCitizenshipException 
         */
	public void setCitizenship(String citizenship) throws InvalidCitizenshipException {
		if (citizenship == "") {
			throw new InvalidCitizenshipException();
		} else {
			this.citizenship = citizenship;
		}		
	}
        /**
         * set active status
         * @param isActive 
         */
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
        /**
         * toString method
         * @return 
         */
	public String toString() {
		return code;
	}
}
