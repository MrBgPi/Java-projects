Assignment 3 

What the program does.
The program uses the users SLL java file the it runs SLL Users though JUnitTest cases to determine whether they pass or fail validation

Date.
Apr 10, 2022

Author
Phi Nguyen


How to run the program.
This application must have a total of 3 package files between 2 differnt folders. Use a Java IDE and use the Run button so that the program can run JUnitTest cases, any file is applicable.