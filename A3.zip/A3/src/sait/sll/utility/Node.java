package sait.sll.utility;

import java.io.Serializable;

/**
 * Getters and Setters class
 * @author Phi Nguyen
 *
 */
public class Node  implements Serializable 
{
	private Object data;	
	private Node next;
	
	/**
	 * Constructor
	 * @param Object data 
	 */
	public Node(Object data) 
	{
		this.data = data;
		next = null;
	}
	
	/**
	 * Gets data in the node.
	 * @return Object data
	 */
	public Object getData() 
	{
		return data; 
	}
	
	/**
	 * Sets data in the node.
	 * @param Oject data 
	 */
	public void setData(Object data) 
	{
		this.data = data;
	}

	/**
	 * Gets next node 
	 * @return Node next.
	 */
	public Node getNext() 
	{
		return next;
	}
	
	/**
	 * Sets next node.
	 * @param Node next 
	 */
	public void setNext(Node next) 
	{
		this.next = next;
	}
}
