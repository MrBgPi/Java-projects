package sait.sll.utility;

import java.io.NotSerializableException;

/**
 * Methods Implementation 
 * @author Phi Nguyen
 *
 */
public class SLL implements LinkedListADT {
	// The first node
	private Node head;

	// Number of nodes 
	private int size;
	
	/**
	 * Constructor
	 * @throws NotSerializableException
	 */
	public SLL() throws NotSerializableException {
		this.head = null;
		this.size = 0;
	}
	
	/**
	 * Checks if the index is out of range
	 * @param index
	 */
	private void checkElementIndexException(int index)  {
		if (index < 0 || index >= size()) {
			throw new IndexOutOfBoundsException();
		}
	}

	/**
	 * Prepend node object
	 * @param Object data
	 */
	public void prepend(Object data) {
		// Generate new node object
		Node currentNode = new Node(data);

		currentNode.setNext(head);
		head = currentNode;
		
		size += 1;
	}


	/**
	 * Clears object
	 */
	@Override
	public void clear() {
		head = null;
		size = 0;
	}
	
	/**
	 * Appends object 
	 * @param Object data
	 */
	@Override
	public void append(Object data) {
		Node appendNode = new Node(data);

		if (head == null) 
			prepend(data);
		else {
			Node currentNode = head;
			while(currentNode.getNext() != null) {
				currentNode = currentNode.getNext();
			}
			currentNode.setNext(appendNode);
			
			size += 1;
		}
	}
	
	/**
	 * Gets list size
	 * @return size
	 */
	@Override
	public int size() {		
		return size;
	}
	
	/**
	 * Replaces node with a given index
	 * @param Object data
	 * @param index
	 * @throws IndexOutOfBoundsException
	 */
	@Override
	public void replace(Object data, int index) throws IndexOutOfBoundsException {
		Node currentNodeNode = head;
		
		checkElementIndexException(index);

		for (int i = 0; i < index; i++) {
			currentNodeNode = currentNodeNode.getNext();
		}
		currentNodeNode.setData(data);
				
	}
	
	/**
	 * Inserts node with a given index
	 * @param Object data
	 * @param index
	 * @throws IndexOutOfBoundsException
	 */
	@Override
	public void insert(Object data, int index) throws IndexOutOfBoundsException {
		Node previousNode  = head;
		Node nodeInsert = new Node(data);
		
		checkElementIndexException(index);
		
		for (int i = 0; i < index - 1; i++) {
			previousNode = previousNode.getNext();
		}
		Node currentNode = previousNode.getNext();
		previousNode.setNext(nodeInsert);
		nodeInsert.setNext(currentNode);
		
		size += 1;
		
	}

	/**
	 * Deletes node with a given index
	 * @param index
	 * @throws IndexOutOfBoundsException
	 */
	@Override
	public void delete(int index) throws IndexOutOfBoundsException {
		Node previousNode = head;
		
		checkElementIndexException(index);
		
		if (index != 0) {
			for (int i = 0; i <  index - 1 ; i++) {
				previousNode = previousNode.getNext();
			}
			Node currentNode = previousNode.getNext();
			previousNode.setNext(currentNode.getNext());
			currentNode = null;
			
			size -= 1;
		}
	}

	/**
	 * Retrieves node object with a given index
	 * @param index
	 * @throws IndexOutOfBoundsException
	 * @return retrieved node
	 */
	@Override
	public Object retrieve(int index) throws IndexOutOfBoundsException {
		Node nodeRetrieve = head;
		
		checkElementIndexException(index);
		
		for (int i = 0; i < index; i++) {		
			nodeRetrieve = nodeRetrieve.getNext();
		}
		
		return nodeRetrieve.getData();
	}
	
	/**
	 * Gets index of node
	 * @param Object data
	 * @return i
	 */
	@Override
	public int indexOf(Object data) {
		Node currentNode = head;
		int i = 0;
	
		while (currentNode != null) {
			if (data == currentNode.getData()) 
				return i;			
			currentNode = currentNode.getNext();
			i += 1;
		}
	    return -1;
		
	}
	
	/**
	 * Checks if list contains object
	 * @param Object data 
	 * @return isContains
	 */
	@Override
	public boolean contains(Object data) {
		boolean isContains = (indexOf(data) >= 0) ? true : false;

		return isContains;
	}
	
	/**
	 * Checks if empty
	 * @return isEmpty
	 */
	@Override
	public boolean isEmpty() {
		boolean isEmpty = (head == null) ? true : false;

		return isEmpty;
	}
}