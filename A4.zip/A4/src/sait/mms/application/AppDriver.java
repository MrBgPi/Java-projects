package sait.mms.application;

import sait.mms.drivers.MariaDBDriver;
import sait.mms.managers.MovieManagementSystem;
import sait.mms.problemdomain.Movie;

import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 * Class app start
 */
public class AppDriver {

    /** Field connection string */
    private static final String CONNECTION_STRING = "jdbc:mariadb://localhost:3306/";
    /** Field database name */
    private static final String DATABASE = "cprg1251";
    /** Field username */
    private static final String USER = "root";
    /** Field password */
    private static final String PASSWORD = "password";


    /**
     * Method launch app
     * @param args - Arguments when launching the program
     */
    public static void main(String[] args) {

        MariaDBDriver mariaDBDriver = new MariaDBDriver(CONNECTION_STRING, DATABASE, USER, PASSWORD);
        mariaDBDriver.connect();

        if (mariaDBDriver.isConnection()){
            MovieManagementSystem movieManagementSystem = new MovieManagementSystem(mariaDBDriver);
            Scanner scanner = new Scanner(System.in);

            int minYear = 1900;
            int maxYear = 2022;

            boolean isWork = true;
            while (isWork) {
                movieManagementSystem.displayMenu();
                System.out.println("----------------------------------------------");
                int userChoose = 0;
                while (true) {
                    try {
                        System.out.print("Enter a number 1-5 to choose an action: ");
                        userChoose = scanner.nextInt();
                        if (userChoose < 1 || userChoose > 5) {
                            System.out.println("The number must be in the range 1-5 !");
                        } else {
                            break;
                        }
                    } catch (InputMismatchException inputMismatchException) {
                        System.out.println("You didn't enter a number!");
                        scanner.nextLine();
                    } catch (NoSuchElementException noSuchElementException) {
                        isWork = false;
                        break;
                    }
                }

                switch (userChoose) {
                    case 1: {

                        int duration = 0;
                        String title = null;
                        int year = 0;

                        while (duration == 0) {
                            try {
                                System.out.print("Input duration: ");
                                duration = scanner.nextInt();
                                if (duration < 1) {
                                    System.out.println("Duration must be greater than 0");
                                    duration = 0;
                                }
                            } catch (InputMismatchException inputMismatchException) {
                                System.out.println("You didn't enter a number!");
                                duration = 0;
                                scanner.nextLine();
                            } catch (NoSuchElementException noSuchElementException) {
                                isWork = false;
                                break;
                            }
                        }
                        scanner.nextLine();
                        while (title == null){
                            try {
                                System.out.print("Input title: ");
                                title = scanner.nextLine();
                                if (title.isEmpty() || title.replaceAll(" ", "").replaceAll("\t", "").length() == 0) {
                                    System.out.println("Title cannot be empty");
                                    title = null;
                                }
                            } catch (NoSuchElementException noSuchElementException) {
                                isWork = false;
                                break;
                            }
                        }
                        while (year == 0) {
                            try {
                                System.out.print("Input year: ");
                                year = scanner.nextInt();
                                if (year < minYear || year > maxYear) {
                                    System.out.printf("The year must be in the range %d-%d !%n", minYear, maxYear);
                                    year = 0;
                                }
                            } catch (InputMismatchException inputMismatchException) {
                                System.out.println("You didn't enter a number!");
                                year = 0;
                                scanner.nextLine();
                            } catch (NoSuchElementException noSuchElementException) {
                                isWork = false;
                                break;
                            }
                        }

                        Movie movie = new Movie();

                        movie.setDuration(duration);
                        movie.setTitle(title);
                        movie.setYear(year);

                        movieManagementSystem.addMovie(movie);

                        System.out.println("Movie created!");

                        break;
                    }

                    case 2: {
                        int year = 0;
                        while (year == 0) {
                            try {
                                System.out.print("Input year: ");
                                year = scanner.nextInt();
                                if (year < minYear || year > maxYear) {
                                    System.out.printf("The year must be in the range %d-%d !%n", minYear, maxYear);
                                    year = 0;
                                }
                            } catch (InputMismatchException inputMismatchException) {
                                System.out.println("You didn't enter a number!");
                                year = 0;
                                scanner.nextLine();
                            } catch (NoSuchElementException noSuchElementException) {
                                isWork = false;
                                break;
                            }
                        }
                        movieManagementSystem.printMoviesInYear(year);
                        break;
                    }

                    case 3: {
                        int countMovies = 0;

                        while (countMovies == 0) {
                            try {
                                System.out.print("Input count: ");
                                countMovies = scanner.nextInt();
                                if (countMovies < 0) {
                                    System.out.println("The count must be greater than 0");
                                    countMovies = 0;
                                }
                            } catch (InputMismatchException inputMismatchException) {
                                System.out.println("You didn't enter a number!");
                                countMovies = 0;
                                scanner.nextLine();
                            } catch (NoSuchElementException noSuchElementException) {
                                isWork = false;
                                break;
                            }
                        }

                        movieManagementSystem.printRandomMovies(countMovies);

                        break;
                    }

                    case 4: {

                        int id = 0;

                        while (id == 0) {
                            try {
                                System.out.print("Input id: ");
                                id = scanner.nextInt();
                                if (id < 0) {
                                    System.out.println("The id must be greater than 0");
                                    id = 0;
                                }
                            } catch (InputMismatchException inputMismatchException) {
                                System.out.println("You didn't enter a number!");
                                id = 0;
                                scanner.nextLine();
                            } catch (NoSuchElementException noSuchElementException) {
                                isWork = false;
                                break;
                            }
                        }

                        movieManagementSystem.deleteMovie(id);

                        System.out.println("Movie removed!");

                        break;
                    }

                    case 5: {
                        isWork = false;
                        break;
                    }

                }

                System.out.println("----------------------------------------------");

            }
            mariaDBDriver.disconnect();
        }

        System.out.println("Exit...");
    }
}
