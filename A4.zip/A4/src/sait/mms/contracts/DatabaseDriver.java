package sait.mms.contracts;

import java.sql.ResultSet;

/**
 * Interface with methods for working with a database
 */
public interface DatabaseDriver {
    /** Method connects to database */
    void connect();

    /**
     * Method gets values from database (SELECT)
     * @param query - Query to database (SELECT query)
     * @return Result from database
     */
    ResultSet get(String query);

    /**
     * Method updates value in database (INSERT, UPDATE, DELETE)
     * @param query - Query to database (INSERT, UPDATE, DELETE)
     */
    void update(String query);

    /**
     * Method disconnects from database
     */
    void disconnect();
}
