package sait.mms.drivers;

import sait.mms.contracts.DatabaseDriver;

import java.io.*;
import java.sql.*;

/**
 * Class driver for MariaDB
 */
public class MariaDBDriver implements DatabaseDriver {

    /** Field connection to database */
    private Connection connection = null;
    /** Field connection string*/
    private final String connectionString;
    /** Field name database */
    private final String dataBase;
    /** Field username */
    private final String user;
    /** Field password */
    private final String password;

    /**
     * Constructor MariaDBDriver
     * @param connectionString - Connection string
     * @param dataBase - Database name
     * @param user - Username
     * @param password - Password
     */
    public MariaDBDriver(String connectionString, String dataBase, String user, String password) {
        this.connectionString = connectionString;
        this.dataBase = dataBase;
        this.user = user;
        this.password = password;
    }

    /**
     * Method check on connect to database
     * @return If connection == null return true, else - return false
     */
    public boolean isConnection() {
        return connection != null;
    }

    /**
     * Method create database
     */
    private void createDatabase(){
        System.out.println("Creating database...");
        try {
            connection = DriverManager.getConnection(connectionString, user, password);
            BufferedReader reader = new BufferedReader(new FileReader("res/movies.sql"));
            String line;
            String script = "";

            String createDatabase = String.format("CREATE DATABASE %s", dataBase);

            while ((line = reader.readLine()) != null){
                script += line;
            }
            update(createDatabase);
            update(script);
            System.out.println("Database create!");
            connection = DriverManager.getConnection(connectionString + dataBase, user, password);
        } catch (FileNotFoundException ex) {
            connection = null;
            System.out.println("File not found!");
        } catch (IOException ex) {
            connection = null;
            System.out.println("An error occurred while working with the file!");
        } catch (SQLException e) {
            connection = null;
            System.out.println("An error occurred while connecting to the database");
        }

    }

    /**
     * Method create connect. If an exception is thrown at run time, the createDatabase method will be called.
     */
    @Override
    public void connect() {
        try {
            connection = DriverManager.getConnection(connectionString + dataBase, user, password);
        } catch (SQLException e) {
            if (e.getErrorCode() == 1049) {
                connection = null;
                createDatabase();
            }else{
                System.out.println("An error occurred while connecting to the database");
            }
        }
    }

    /**
     * Method gets values from database (SELECT)
     * @param query - Query to database (SELECT query)
     * @return Result from database
     */
    @Override
    public ResultSet get(String query) {
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            statement.close();
            return resultSet;
        } catch (SQLException e) {
            System.out.println("An error occurred while running");
        }
        return null;
    }

    /**
     * Method updates value in database (INSERT, UPDATE, DELETE)
     * @param query - Query to database (INSERT, UPDATE, DELETE)
     */
    @Override
    public void update(String query) {
        try {
            Statement statement = connection.createStatement();
            statement.executeUpdate(query);
            statement.close();
        } catch (SQLException e) {
            System.out.println("An error occurred while running");
        }
    }

    /**
     * Method disconnects from database
     */
    @Override
    public void disconnect() {
        try {
            connection.close();
        } catch (SQLException e) {
            System.out.println("An error occurred while running");
        }
    }

}
