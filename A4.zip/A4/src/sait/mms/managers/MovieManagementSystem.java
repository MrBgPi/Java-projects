package sait.mms.managers;

import sait.mms.drivers.MariaDBDriver;
import sait.mms.problemdomain.Movie;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * Class for work with Movie System
 */
public class MovieManagementSystem {

    /** Field DBDriver */
    private final MariaDBDriver mariaDBDriver;

    /**
     * Constructor MariaDBDriver
     * @param mariaDBDriver - Driver database
     */
    public MovieManagementSystem(MariaDBDriver mariaDBDriver) {
        this.mariaDBDriver = mariaDBDriver;
    }

    /**
     * Method print display menu
     */
    public void displayMenu() {
        System.out.println("1. Create a new movie");
        System.out.println("2. Get movies released in a specific year");
        System.out.println("3. Get random movies");
        System.out.println("4. Delete movie using id");
        System.out.println("5. Exit program");
    }

    /**
     * Method for add movie to database
     * @param movie - Object movie for insert to database
     */
    public void addMovie(Movie movie) {
        String query = String.format("INSERT movies(duration, title, year) VALUES (%d, '%s', %d)", movie.getDuration(), movie.getTitle(), movie.getYear());
        mariaDBDriver.update(query);
    }

    /**
     * Method print movies specific year
     * @param year - Specific year
     */

    public void printMoviesInYear(int year) {
        String query = String.format("SELECT * FROM movies WHERE year = %d", year);
        ResultSet resultSet = mariaDBDriver.get(query);
        try {
            while (resultSet.next()) {
                Movie movie = new Movie();
                int id = resultSet.getInt(1);
                movie.setDuration(resultSet.getInt(2));
                movie.setTitle(resultSet.getString(3));
                movie.setYear(resultSet.getInt(4));
                System.out.println(String.format("ID: \t\t%d", id));
                System.out.println(movie);
                System.out.println("----------------------------------------------");
            }
        } catch (SQLException e) {
            System.out.println("An error occurred while running");
        }
    }

    /**
     * Method print random movies
     * @param count - Count random movies
     */
    public void printRandomMovies(int count) {
        String query = String.format("SELECT * FROM movies ORDER BY RAND() LIMIT %d", count);
        ResultSet resultSet = mariaDBDriver.get(query);
        try {
            while (resultSet.next()) {
                Movie movie = new Movie();
                int id = resultSet.getInt(1);
                movie.setDuration(resultSet.getInt(2));
                movie.setTitle(resultSet.getString(3));
                movie.setYear(resultSet.getInt(4));
                System.out.println(String.format("ID: \t\t%d", id));
                System.out.println(movie);
                System.out.println("----------------------------------------------");
            }
        } catch (SQLException e) {
            System.out.println("An error occurred while running");
        }
    }

    /**
     * Method delete movie
     * @param id - ID movie in database
     */
    public void deleteMovie(int id) {
        String query = String.format("DELETE FROM Movies WHERE Id = %d", id);
        mariaDBDriver.update(query);
    }

}
