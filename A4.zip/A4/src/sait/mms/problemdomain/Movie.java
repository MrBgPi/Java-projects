package sait.mms.problemdomain;

/**
 * Class model Movie
 */
public class Movie {

    /** Field duration */
    private int duration;
    /** Filed title */
    private String title;
    /** Field year */
    private int year;

    /**
     * Method get duration
     * @return duration
     */
    public int getDuration() {
        return duration;
    }

    /**
     * Method set duration
     * @param duration - Duration for set
     */
    public void setDuration(int duration) {
        this.duration = duration;
    }

    /**
     * Method get title
     * @return title
     */
    public String getTitle() {
        return title;
    }

    /**
     * Method set title
     * @param title - Title for set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Method get year
     * @return year
     */
    public int getYear() {
        return year;
    }


    /**
     * Method set year
     * @param year - Year for set
     */
    public void setYear(int year) {
        this.year = year;
    }

    /**
     * Method toString for beautifully print
     * @return String format with field movie
     */
    @Override
    public String toString() {
        return String.format("Title: \t\t%s\n", title) + String.format("Year: \t\t%d\n", year) + String.format("Duration: \t%d", duration);
    }
}
