/*

Program: Faculty.java          Date: 19-Oct-2020

Purpose: Faculty class

Author: Phi Nguyen, 
School: CHHS
Course: Computer Programming 30
 
*/

package Exercise1;

public class Faculty extends UEmployee {
    private String departmentName;
    
    /**
     * Constructor
     * pre: none
     * post: a Faculty object has been created
     * @param department 
     */
    public Faculty(String department, String name, double salary) {
        super(name, salary);
        departmentName = department;
    }
    
    /**
     * A method that converts objects to String
     * pre: none
     * post: returns a string states the department's name
     * @return 
     */
    public String getDepartment() {
        return departmentName;
    }
    
    /**
     * Returns a String that represents the Faculty obj
     * pre: none
     * post: A string has been returned
     * @return 
     */
    public String toString() {
        String department;
        
        department = "\nEmployee name: " + super.getName() 
                + "\nDepartment: " + departmentName + "\nSalary: " 
                + super.getSalary();
        
        return department;
    }
}
/* Screen Dump
 

*/