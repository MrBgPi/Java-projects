/*

Program: Staff.java          Date: 19-Oct-2020

Purpose: Staff class

Author: Phi Nguyen, 
School: CHHS
Course: Computer Programming 30
 
*/

package Exercise1;

public class Staff extends UEmployee {
    private String job;
    
    /**
     * Constructor
     * pre: none
     * post: A Staff has been created
     * @param jobName
     * @param name
     * @param salary 
     */
    public Staff(String jobName, String name, double salary) {
        super(name, salary);
        job = jobName;
    }
    
    /**
     * Convert objects to Strings
     * pre: none
     * post: Returns the title of the job
     * @return 
     */
    public String getJobName() {
        return job;
    }
    
    /**
     * Returns a String represents the Staff obj
     * pre: none
     * post: a String has been returned
     * @return 
     */
    public String toString() {
        String emInfo;
        
        emInfo = "\nEmployee name: " + super.getName() 
                + "\nJob: " + job + "\nSalary: " 
                + super.getSalary();
        
        return emInfo;       
    }
}
/* Screen Dump
 

*/