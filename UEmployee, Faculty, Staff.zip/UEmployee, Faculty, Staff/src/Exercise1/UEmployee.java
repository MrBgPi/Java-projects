/*

Program: UEmployee.java          Date: 19-Oct-2020

Purpose: An abstract class

Author: Phi Nguyen, 
School: CHHS
Course: Computer Programming 30
 
*/

package Exercise1;


public abstract class UEmployee {
    private String emName;
    private double salary;
    
    /**
     * constructor
     * pre: none
     * post: a UEmployee has been created
     * @param name
     * @param pay 
     */
    public UEmployee(String name, double pay) {
        emName = name;
        salary = pay;
    }
    
    /**
     * A method that is used to get the name of employee
     * pre: none
     * post: returns the name of the employee
     * @return 
     */
    public String getName() {
        return emName;
    }
    
    /**
     * Gets the salary from the user
     * pre: none
     * post: returns the salary of the employee
     * @return 
     */
    public double getSalary() {
        return salary;
    }
    
}
/* Screen Dump
 

*/