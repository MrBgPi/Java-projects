/*

Program: testClass.java          Date: 19-Oct-2020

Purpose: An application that is used to display university employee profile via OOP 

Author: Phi Nguyen, 
School: CHHS
Course: Computer Programming 30
 
*/

package Exercise1;

import java.util.Scanner;

public class testClass {
    static Scanner input = new Scanner(System.in);
    
    /**
     * Creates new Staff obj
     * pre: none
     * post: A new Staff obj has been recorded 
     */
    public static void staff() {
        UEmployee newStaff;
        String name, job;
        double salary;
        
        System.out.print("\nEnter your name: ");
        name = input.next();
        System.out.print("Enter your salary: ");
        salary = input.nextDouble();
        System.out.print("Enter your job: ");
        job = input.next();
        
        newStaff = new Staff(job, name, salary);
        
        System.out.println(newStaff);
    }
    
    /**
     * Creates new Faculty obj
     * pre: none
     * post: A new Faculty obj has been recorded 
     */
    public static void faculty() {
        UEmployee newFaculty;
        String name, department;
        double salary;
        
        System.out.print("\nEnter your name: ");
        name = input.next();
        System.out.print("Enter your salary: ");
        salary = input.nextDouble();
        System.out.print("Enter your department: ");
        department = input.next();
        
        newFaculty = new Faculty(department, name, salary);
        
        System.out.println(newFaculty);
    }
    
    public static void main(String[] args) {
        String choice;
        
        System.out.println("Welcome to The Buffalo University!");
        System.out.println("---------------------------------");
        System.out.println("Staff (S)/Faculty (F)/Quit (Q)");        
        
        do{
            System.out.println("\nYou are?");
            System.out.print("-> ");
            choice = input.next();
            
            if (choice.equalsIgnoreCase("S")) {
                staff();
            } else if (choice.equalsIgnoreCase("F")) {
                faculty();
            }
        } while (!choice.equalsIgnoreCase("Q"));
    }
}
/* Screen Dump
Welcome to The Buffalo University!
---------------------------------
Staff (S)/Faculty (F)/Quit (Q)

You are?
-> S

Enter your name: Diego
Enter your salary: 80000
Enter your job: CS instructor

Employee name: Diego
Job: CS instructor
Salary: 80000.0

You are?
-> Q
*/